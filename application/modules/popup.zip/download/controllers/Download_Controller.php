<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Download_Controller extends Front_Controller {

    public function __construct() {

        parent::__construct();
        $this->load->library('session');
    }

    public function index($slug = '') {
		
		$file = $this->doctrine->em->getRepository('downloads\models\Download')->findBy(array('slug'=>$slug));
		$nameOld = base_url() . "assets/upload/downloads/" . $file[0]->getFile();
        $pathinfo = (pathinfo($nameOld));
        $extension = $pathinfo['extension'];
        $nameNew = str_replace(' ', '-', $file[0]->getSlug()) ;
        header("Content-Transfer-Encoding: binary");
        header('Content-type: application/' . $extension);
        header("Content-disposition: attachment; filename=$nameNew");
        readfile($nameOld);
    }
}
