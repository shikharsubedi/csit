<?php

namespace testimonial\models;

use Doctrine\ORM\EntityRepository;
//    Doctrine\ORM\Query;

class TestimonialRepository extends EntityRepository {

    

}
