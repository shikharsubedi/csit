<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Testimonial_Controller extends Front_Controller {

    public function index() {
        $repo = &$this->doctrine->em->getRepository('testimonial\models\Testimonial');
        $testimonial = $repo->findBy(array('status' => '1'));
        $this->load->theme("testimonial_list", array('testimonial' => $testimonial)); 
    }

    public function showFront() {
        $repo = &$this->doctrine->em->getRepository('testimonial\models\Testimonial');
        $testimonial = $repo->findBy(array('status' => '1', 'showFront' => '1'), array('id' => 'DESC'),1);
        $this->load->theme("testimonial", array('testimonial' => $testimonial)); 
    }
    

}
