<div class="section">
	<h4>Add a Team</h4>
    <div class="content">
    	<form name="add_team" id="add_team" method="post" action="">
        	<table class="form-table">
            	<tr>
                	<th scope="row"><label for="team_name">Name : </label></th>
                    <td><input type="text" name="team_name" id="team_name" class="regular-text required"></td>
                </tr>
                <tr>
                	<td colspan="2"><input type="submit" value="Add" class="button" /></td>
                </tr>
            </table>
        </form>
    </div>
    </div>