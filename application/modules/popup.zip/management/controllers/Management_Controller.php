<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/*
 * * front controller
 */

class Management_Controller extends Front_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('breadcrumb');
        $this->breadcrumb->append_crumb('About Us', 'content/about-us');
    }

    public function index() {
        $id = Options::get('homepage_message');
        $management = $this->doctrine->em->getRepository('management\models\Management')->findBy(array("active"=>'1'),array("order"=>"ASC"));
        $data['management'] = $management;

        $this->load->theme("mgmt_team_list", $data);
    }
    
    public function indexA() {
        $id = Options::get('homepage_message');
        $management = $this->doctrine->em->getRepository('management\models\Management')->findBy(array("active"=>'1', ),array("order"=>"DESC"));
        $data['message'] = $management;

        $this->load->theme("homepage_message", $data);
    }

    public function showFront() {
        $repo = $this->doctrine->em->getRepository('management\models\Management');
        $showFront = $repo->findBy(array('active' => '1', 'showFront' => '1'), array('order' => 'DESC'),3);
        $data['showFront']=$showFront;
        $this->load->theme("mgmt_team_front", $data);
    }
    
    public function showWholeContent($id) {
        $repo = $this->doctrine->em->find('management\models\Management',$id);
        $data['content']=$repo;
        $this->load->theme("mgmt_member_page", $data);
    }

    public function _type($id = '') {

        $memberRepo = &$this->doctrine->em->getRepository('management\models\Management');
        $items = $memberRepo->getMembers($id, true);

        $data['items'] = & $items;
        $this->load->theme('mgmt', $data);
    }

    public function _item($id = '') {

        $memberRepo = &$this->doctrine->em->getRepository('management\models\Management');
        $items = $memberRepo->getMembers($id, true);

        $data['items'] = & $items;

        $this->load->theme('mgmt', $data);
    }

    public function bod($slug) {
        $membertRepo = &$this->doctrine->em->getRepository('management\models\ManagementType');
        $team = $membertRepo->findBy(array('slug' => $slug));

        $memberRepo = &$this->doctrine->em->getRepository('management\models\Management');

        $items = $memberRepo->getMembers($team[0]->id(), true);
        $t['items'] = $items;
        $cat[] = $t;

        $this->_t['team_cat'] = &$cat;

        $this->load->view('management/front/bod', $this->_t);
        //$this->load->theme('mgmt', $this->_t);
    }

    public function profile($id) {
        $memberRepo = &$this->doctrine->em->getRepository('management\models\ManagementType');
        $items = $memberRepo->getMembersof($id, true);

        $data['items'] = & $items;

        $this->load->theme('mgmt', $data);
        //$this->load->theme('mgmt', $this->_t);
    }

}
