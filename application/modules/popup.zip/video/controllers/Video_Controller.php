<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Video_Controller extends Front_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->_t['sitetitle'] = $this->_CONFIG['admin_name'];
    }

    public function index($catId='1') {
        $cateRepo = $this->doctrine->em->getRepository('video\models\Video');
        $videos = $cateRepo->findBy(array('active' => '1', 'category' => $catId));
        $this->_t['videos'] = $videos;
        $this->load->theme('videos',  $this->_t);
    }

    

    public function sidevideo() {

        $vidId = Options::get('home_video_side');
        if ($vidId) {

            $video = $this->doctrine->em->find('video\models\Video', $vidId);
            //$repo = $this->doctrine->em->getRepository('video\models\Video');
            //$videos = $repo->getVideo($catId);
            //$this->_t['cat'] = $cat;
            $this->_t['video'] = $video;
            $this->load->theme('video-side', $this->_t);
        }
    }

    public function videolistt($slug, $offset = 0) {

        $perpage = 5;
        $repo = $this->doctrine->em->getRepository('video\models\Video');
        $video = $repo->findVideoByCategorySlug($slug, $perpage, $offset, TRUE);
        $popular = $repo->getPopular();


        $this->_t['popular'] = $popular;
        $this->_t['video'] = $video['video'];
        $this->load->theme('video-list', $this->_t);
    }

    public function popular() {

        $repo = $this->doctrine->em->getRepository('video\models\Video');
        $video = $repo->getPopular();
        show_pre($video);
        $this->load->theme('video-popular', $this->_t);
    }

    public function videolist($slug, $offset = 0) {

        $perpage = 10;
        $repo = $this->doctrine->em->getRepository('video\models\Video');
        if ($_GET) {
            $alphabet = $_GET['alphabet'];
            if ($alphabet) {
                $video = $repo->getAlbhabetwise($alphabet, $slug);
                $this->_t['filter'] = TRUE;
            }
        } else {

            $v = $repo->findVideoByCategorySlug($slug, $perpage, $offset, TRUE);
            $video = $v['video'];

            $numContent = $v['total'];
            if ($numContent > $perpage) {
                $this->load->library('pagination');

                $config['base_url'] = base_url() . "video/videolist/" . $slug;
                $config['total_rows'] = $numContent;
                $config['per_page'] = $perpage;
                $config['uri_segment'] = 4;
                $config['prev_link'] = 'Previous';
                $config['next_link'] = 'Older';

                $this->pagination->initialize($config);
                $pg = $this->pagination->create_links();
                $this->_t['pagination'] = $pg;
            }
        }
        $popular = $repo->getPopularbyCat($slug);



        $this->_t['slug'] = $slug;
        $this->_t['popular'] = $popular;
        $this->_t['video'] = $video;
        $this->load->theme('video-list', $this->_t);
    }

    public function watch($id) {

        $perpage = 6;
        $vid = $this->doctrine->em->find('video\models\Video', $id);
        $repo = $this->doctrine->em->getRepository('video\models\Video');
        $cat = $vid->getCategory();

        $video = $repo->findVideoByCategory($cat->getSlug(), $perpage);
        $popular = $repo->getPopularbyCat($cat->getSlug());
        $this->_t['video'] = $video['video'];
        $this->_t['popular'] = $popular;
        $this->_t['cat'] = $cat;
        $this->_t['vid'] = $vid;
        $this->load->theme('video-watch', $this->_t);
    }

    public function updateviews() {
        $id = $this->input->post('video');
        $video = $this->doctrine->em->find('video\models\Video', $id);
        $views = ($video->getViews() ) ? $video->getViews() : 0;
        $video->setViews($views + 1);
        $this->doctrine->em->persist($video);
        $this->doctrine->em->flush();
    }

}
