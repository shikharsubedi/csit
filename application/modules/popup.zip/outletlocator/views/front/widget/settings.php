
<div class="widget">
  <div class="visa">
    <p class="head">Indian Visa <br />
      Service Center</p>
    <p><a href="#">Read More »</a></p>
  </div>
</div>
