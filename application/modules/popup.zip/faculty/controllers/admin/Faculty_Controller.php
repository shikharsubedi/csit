<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

use faculty\models\Faculty;
use faculty\models\ApplyToFaculty;

class Faculty_Controller extends Admin_Controller {

    public function __construct() {
        parent::__construct();
        if (!user_access('faculty list'))
            admin_redirect();
        $this->load->library('ThumbLib');
        $this->breadcrumb->append_crumb('Faculty', admin_url('faculty'));
    }

    public function index() {
        $repo = $this->doctrine->em->getRepository('faculty\models\Faculty');
        $faculty = $repo->findAll();
        $this->templatedata['faculty'] = $faculty;
        $this->templatedata['maincontent'] = 'faculty/admin/list';
        $this->templatedata['flashdata'] = $this->session->flashdata('feedback');
        $this->load->view('admin/master', $this->templatedata);
    }

    public function add() {
        if ($this->input->post()) {
            $this->load->library('form_validation');

            $this->form_validation->set_rules('name', 'Name', 'required');

            if ($this->form_validation->run()) {
                $faculty = new Faculty();

                $faculty->setName($this->input->post('name'));
                $faculty->setStatus($this->input->post('isActive'));
                $faculty->setDescription($this->input->post('description'));


                $this->doctrine->em->persist($faculty);
                $this->doctrine->em->flush();

                $this->templatedata['flashdata'] = $this->session->flashdata('feedback', 'Faqcat added successfully.');
                admin_redirect('faculty');
            }
        }
        $this->breadcrumb->append_crumb('Add Faculty', admin_url(''));
        array_push($this->templatedata['scripts'], 'ckeditor/ckeditor');
        array_push($this->templatedata['scripts'], 'ckfinder/ckfinder');
        $this->templatedata['flashdata'] = $this->session->flashdata('feedback');
        $this->templatedata['maincontent'] = 'faculty/admin/add';
        $this->load->view('admin/master', $this->templatedata);
    }

}
