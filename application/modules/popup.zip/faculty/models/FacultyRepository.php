<?php

namespace faculty\models;

use Doctrine\ORM\EntityRepository,
    Doctrine\ORM\Query;

class FacultyRepository extends EntityRepository {

    

}
