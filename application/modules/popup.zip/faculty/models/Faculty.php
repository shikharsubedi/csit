<?php

namespace faculty\models;

use Gedmo\Mapping\Annotation as Gedmo;
use Doctrine\Common\Collections\ArrayCollection;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * @Entity(repositoryClass="faculty\models\FacultyRepository")
 * @Table(name="dtn_faculty")
 */
class Faculty {

    /**
     * @Id
     * @Column(type="integer")
     * @GeneratedValue
     */
    private $id;

    /**
     * @Column(type="string", length=255, nullable=true)
     */
    private $name;
    
    /**
     * @Column(type="string", length=255, nullable=true)
     */
    private $description;

    /**
     * @OneToMany(targetEntity="faculty\models\ApplyToFaculty", mappedBy="faculty")
     * @JoinColumn(onDelete="cascade")
     */
    private $appliedStudents;

    /**
     * @Column(type="integer", nullable=true)
     */
    private $orderBy;

    /**
     * @Column(type="boolean", nullable=false)
     */
    private $status = 1;

    public function __construct() {
        
    }
    function getDescription() {
        return $this->description;
    }

    function setDescription($description) {
        $this->description = $description;
    }

        function getOrder() {
        return $this->orderBy;
    }

    function setOrder($orderBy) {
        $this->orderBy = $orderBy;
    }

    function getId() {
        return $this->id;
    }

    function getName() {
        return $this->name;
    }

    function getAppliedStudents() {
        return $this->appliedStudents;
    }

    function getStatus() {
        return $this->status;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setName($name) {
        $this->name = $name;
    }

    function setAppliedStudents($appliedStudents) {
        $this->appliedStudents = $appliedStudents;
    }

    function setStatus($status) {
        $this->status = $status;
    }

}
