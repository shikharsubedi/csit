<?php
 use contactus\models\ContactUs;
 use outletlocator\models\Outlet;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Contactus_Controller extends Front_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
    }

    public function index() {        
        if ($this->input->post()) {
            $this->form_validation->set_rules('name', 'Name', 'required');
            $this->form_validation->set_rules('email', 'Email', 'required');
            $this->form_validation->set_rules('comments', 'Message', 'required');
            //revise validation
            if ($this->form_validation->run($this)) {
                $object = new ContactUs();
                $object->setName(strip_tags($this->input->post('name')));                       
                $object->setEmail($this->input->post('email'));
                $object->setMessage(strip_tags($this->input->post('comments')));
                $object->setEmail(strip_tags($this->input->post('email')));
                $this->doctrine->em->persist($object);
                $this->doctrine->em->flush();
                $this->session->set_success_flashdata('feedback', 'Form submitted successfully.');
                redirect('contactus');
            }else{
                $this->load->theme("contact_us");
            }
        } 
        $outlet=  $this->doctrine->em->getRepository('outletlocator\models\Outlet');
        $outlet=$outlet->findBy(array("status"=>'active'),array('id'=>'DESC'),1);
        $this->_t['outlet']=$outlet;
        $this->load->theme("contact_us",  $this->_t);
        
    }
}
