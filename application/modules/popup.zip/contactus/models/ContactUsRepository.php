<?php

namespace contactus\models;

use Doctrine\ORM\EntityRepository,
    Doctrine\ORM\Query;

class ContactUsRepository extends EntityRepository {

    

}
