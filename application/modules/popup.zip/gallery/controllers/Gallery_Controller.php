<?php

use gallery\models\Album;
use gallery\models\Image;

(defined('BASEPATH')) OR exit('No direct script access allowed');

class Gallery_Controller extends Front_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('breadcrumb');
        $this->load->library('session');
        $this->_t['sitetitle'] = $this->_CONFIG['admin_name'];
    }

    public function index($offset = 0) {
        //for images data
        $images = $this->doctrine->em->getRepository('gallery\models\image');
        $images = $images->findAll();
        $this->_t['images'] = $images;

        //for album data
        if ($this->uri->segment(3) != '')
            $offset = $this->uri->segment(3);

        $albumRepo = $this->doctrine->em->getRepository('gallery\models\Album');
        $albums = $albumRepo->findBy(array('status' => 'active'));
//        echo '<pre>'; \Doctrine\Common\Util\Debug::dump($albums[0]->getImages());exit;

        $per_page = 7;

        $_indices = $albumRepo->getAlbum($offset, $per_page, array('status' => STATUS_ACTIVE));

        $this->_t['albums'] = $albums;

        $numIndexes = $_indices['total'];

        if ($numIndexes > $per_page) {
            $this->load->library('pagination');

            $config['base_url'] = base_url() . "gallery/index/";
            $config['total_rows'] = $numIndexes;
            $config['per_page'] = $per_page;
            $config['uri_segment'] = 3;
            $config['prev_link'] = 'Previous';
            $config['next_link'] = 'Next';

            $this->pagination->initialize($config);
            $this->_t['pagination'] = $this->pagination->create_links();
        }
        $this->load->theme('gallery', $this->_t);
    }

    public function images($album_id, $class, $offset = 0) {

        $album = $this->doctrine->em->find('\gallery\models\Album', $album_id);
        if (!$album or $album->getStatus() == STATUS_INACTIVE)
            show_404();
        $coverimage = $album->getCoverImage()->getName();
        $coverimage = $album->getCoverImage()->getName();


        $this->_t['galleryclass'] = $class;



        $template = 'images';

        $this->_t['album'] = $album;

        $this->load->library('breadcrumb');
        $this->breadcrumb->append_crumb('Gallery', site_url('content/gallery'));
        $this->breadcrumb->append_crumb($album->getName(), site_url('gallery/images/' . $album_id));
        $this->load->theme($template, $this->_t);
    }

    public function _widget() {
        $lang = ($this->session->userdata('lang')) ? $this->session->userdata('lang') : 'nepali';
        $key = ($lang == 'english') ? 'en' : 'np';
        $imageRepo = $this->doctrine->em->getRepository('gallery\models\Album');
        $this->_t['key'] = $key;
        $this->_t['randimage'] = $imageRepo->getRandImage();
        $this->load->theme('gallerywidget', $this->_t);
    }

    public function viewall($offset = 0) {
        if ($this->uri->segment(3) != '')
            $offset = $this->uri->segment(3);

        $albumRepo = $this->doctrine->em->getRepository('gallery\models\Album');


        $per_page = 6;

        $_indices = $albumRepo->getAlbum($offset, $per_page, array('status' => STATUS_ACTIVE));

        $this->_t['albums'] = $_indices['indices'];

        $numIndexes = $_indices['total'];

        if ($numIndexes > $per_page) {
            $this->load->library('pagination');

            $config['base_url'] = base_url() . "gallery/index/";
            $config['total_rows'] = $numIndexes;
            $config['per_page'] = $per_page;
            $config['uri_segment'] = 3;
            $config['prev_link'] = 'Previous';
            $config['next_link'] = 'Next';

            $this->pagination->initialize($config);
            $this->_t['pagination'] = $this->pagination->create_links();
        }

        $template = 'viewallgallery';

        $this->load->theme($template, $this->_t);
    }

    public function showall($offset = 0) {
        if ($this->uri->segment(3) != '')
            $offset = $this->uri->segment(3);

        $albumRepo = $this->doctrine->em->getRepository('gallery\models\Album');

        $per_page = 6;

        $_indices = $albumRepo->getAlbum($offset, $per_page, array('status' => STATUS_ACTIVE));

        $this->_t['albums'] = $_indices['indices'];

        $numIndexes = $_indices['total'];

        if ($numIndexes > $per_page) {
            $this->load->library('pagination');

            $config['base_url'] = base_url() . "gallery/index/";
            $config['total_rows'] = $numIndexes;
            $config['per_page'] = $per_page;
            $config['uri_segment'] = 3;
            $config['prev_link'] = 'Previous';
            $config['next_link'] = 'Next';

            $this->pagination->initialize($config);
            $this->_t['pagination'] = $this->pagination->create_links();
        }

        $template = 'showgallery';

        $this->load->theme($template, $this->_t);
    }

    public function album($slug, $offset = 0) {
        $per_page = 10;
        $gallerynamerepo = $this->doctrine->em->getRepository('gallery\models\Album');
        $gallery_name = $gallerynamerepo->getgalleryname($slug);
        $gallery = $gallery_name[0]['name'];


        $galleryRepo = $this->doctrine->em->getRepository('gallery\models\Image');
        $_indices = $galleryRepo->getallgalleryfront($offset, $per_page, $slug);
        //echo $_indices['total'];exit;
        $numIndexes = $_indices['total'];

        //echo"<pre>";
        //\Doctrine\Common\Util\Debug::dump($_indices);exit;
        if ($numIndexes > $per_page) {
            $this->load->library('pagination');

            $config['base_url'] = base_url() . "gallery/album/" . $slug;
            $config['total_rows'] = $numIndexes;
            $config['per_page'] = $per_page;
            $config['uri_segment'] = 4;
            $config['prev_link'] = 'Previous';
            $config['next_link'] = 'Next';
            $this->pagination->initialize($config);
            $this->_t['pagination'] = $this->pagination->create_links();
        }
        $this->_t['name'] = $gallery;
        $this->_t['images'] = $_indices['indices'];
        $template = 'frontimagegallery';
        $this->load->theme($template, $this->_t);
    }

}
