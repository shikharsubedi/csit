<?php
namespace gallery\models;
 
use Doctrine\ORM\EntityRepository;
use gallery\models\Album,
	gallery\models\Image,
	user\models\user,
	F1soft\DoctrineExtensions\Paginate\Paginate,
	Doctrine\ORM\Query;
 
class AlbumRepository extends EntityRepository
{
	public function getAlbums($filters = NULL)
	{
		
		$qb = $this->_em->createQueryBuilder();
		
		$qb->select(array('s.id','s.name','s.name','s.description','i.name as cover_image','s.created','u.username','s.status'))
			->from('gallery\models\Album','s')
			->join('s.user','u')
			->join('s.coverimage','i')
			->where('1 = 1');
				
		if(is_array($filters) && count($filters) > 0)
		{
			foreach($filters as $k => $v)
				$qb->andWhere("s.".$k."='".$v."'");
		}
			
		$qb->orderBy('s.order','ASC');	
			
		return $qb->getQuery()->getResult();
	}
	
	public function getAlbum($offset = NULL,$perpage = NULL,$filters = NULL)
	{
		$qb = $this->_em->createQueryBuilder();
		$qb->select(array('a.id','a.name','a.name','i.name as cover_image'))
			->from('gallery\models\Album', 'a')
			->join('a.coverimage','i')
			->where('1 = 1');
		if(is_array($filters) && count($filters) > 0)
		{
			foreach($filters as $k => $v)
				$qb->andWhere("a.".$k."='".$v."'");
		}
		
		if(!is_null($perpage))
			$qb->setMaxResults($perpage);
		
		if(!is_null($offset))
			$qb->setFirstResult($offset);	
		
		$qb->orderBy('a.order','ASC');
		
		$query = $qb->getQuery();
				
		$outlets = $query->getResult();
		
		$qb->select(array('s.id'))
			->from('gallery\models\Album','s')
			->where('1 = 1');
		if(is_array($filters) && count($filters) > 0)
		{
			foreach($filters as $k => $v)
				$qb->andWhere("a.".$k."='".$v."'");
		}
		$query = $qb->getQuery();
		
		$totalResults = Paginate::count($query);
		//exit;
		return array(	'total'		=>	$totalResults,
						'indices'	=>	$outlets);
			
	}
	
	public function getRandImage()
	{
		$qb = $this->_em->createQueryBuilder();
		$active = STATUS_ACTIVE;
		$qb->select(array('a.id','i.name'))
			->from('gallery\models\Album', 'a')
			->join('a.coverimage','i')
			->where('1 = 1')
			->andwhere("a.status = '$active'")
			;
		$return = $qb->getQuery()->getResult();
		
		if (count($return) < 1) return NULL;
		
		return $return[array_rand($return)]['name'];			
	}
        public function getgalleryname($slug)
        {
           $qb = $this->_em->createQueryBuilder();
		$active = STATUS_ACTIVE;
		$qb->select(array('i.name'))
			->from('gallery\models\Album', 'i')
			
			->where('1 = 1')
			->andwhere("i.slug = '$slug'")
			;
               // echo $qb->getQuery()->getSQL();exit;
		$return = $qb->getQuery()->getResult();
                return $return;
		
					
	
        }
}
?>